package calificaciones.materia.model;

/* Autor: Cristian Adair Ramirez Rodriguez
 * Materia:Paradigmas I
 * Fecha de creacion: 22 de abril
 * Fecha de modificiación 8 de mayo
 * Grupo:406
*/
import java.util.Scanner;

import calificaciones.materia.controller.EleccionesSemestre;
import calificaciones.materia.pojo.Calificacion;
import calificaciones.materia.pojo.Materias;

public class CalcularPromedio {
	static Scanner s = new Scanner(System.in);

	public void Matuno(double a, double b, double c, double d) {
	}
	

}
