package calificaciones.materia.view;

import java.util.Hashtable;

import calificaciones.materia.controller.EleccionesSemestre;
import calificaciones.materia.controller.PeticionDate;
import calificaciones.materia.model.CalcularPromedio;
import calificaciones.materia.pojo.*;

/* Autor: Cristian Adair Ramirez Rodriguez
 * Materia:Paradigmas I
 * Fecha de creacion: 22 de abril
 * Fecha de modificiación 3 de mayo
 * Grupo:406
*/

public class Principal extends Calificacion{
	public static Alumnos nombre = new Alumnos();
	public static Alumnos grupo = new Alumnos();
	public static Alumnos semestre = new Alumnos();
	public static Alumnos matricula = new Alumnos();
	
	public static PeticionDate PD = new PeticionDate();
	public static EleccionesSemestre elec = new EleccionesSemestre();
	
	public static Materias materia1 = new Materias();
	public static Materias materia2 = new Materias();
	public static Materias materia3 = new Materias();
	public static Materias materia4 = new Materias();
	public static Materias materia5 = new Materias();
	static Calificacion cal =new Calificacion();
	private static Hashtable<String, String> calificacion=new Hashtable<String, String>();
	
	public static void main(String[] args) {
		PD.Alumno(nombre, grupo,semestre, matricula);
		elec.EleccionSemestre(materia1, materia1, materia2, materia3, materia4);
		Calificacion.Mashtable();
		System.out.println("/////////////////////////////////////////////////////////////////////////////////");
		System.out.println("//////// Nombre del alumno: "+Alumnos.getNombre()+"//////////////////////////////");
		System.out.println("//////// Grupo:"+Alumnos.getGrupo()+ "///////semestre"+Alumnos.getSemestre()+"////////////");
		System.out.println("/////////////Matricula:   " +Alumnos.getMatricula()+"///////////////////");
		System.out.println("////////////////Materias//////// Primer parcial/// segundo parcial/// tercar parcial///ordinario////////");
		System.out.println("//" + materia1.getNombre1()+"/////        "+calificacion.get("11")+"////          "+calificacion.get("12")+"//////     "+calificacion.get("13"));
		System.out.println("//" + materia2.getNombre2());
		System.out.println("//" + materia3.getNombre3());
		System.out.println("//" + materia4.getNombre4());
		System.out.println("//" + materia5.getNombre5());
		System.out.println("///////////////////////////////////////////////////////////////////////////////////");
			}
}
