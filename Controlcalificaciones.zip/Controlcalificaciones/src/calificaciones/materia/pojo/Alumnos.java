package calificaciones.materia.pojo;

import javax.swing.JOptionPane;

import calificaciones.materia.controller.PeticionDate;

/* Autor: Cristian Adair Ramirez Rodriguez
 * Materia:Paradigmas I
 * Fecha de creacion: 22 de abril
 * Fecha de modificiación 4 de mayo
 * Grupo:406
*/
public class Alumnos {
	static String nombre;
	static String grupo;
	static String semestre;
	static String matricula;
	public static String getNombre() {
		return nombre;
	}
	public static void setNombre(String nombre) {
		Alumnos.nombre = nombre;
	}
	public static String getGrupo() {
		return grupo;
	}
	public static void setGrupo(String grupo) {
		Alumnos.grupo = grupo;
	}
	public static String getSemestre() {
		return semestre;
	}
	public static void setSemestre(String semestre) {
		Alumnos.semestre = semestre;
	}
	public static String getMatricula() {
		return matricula;
	}
	public static void setMatricula(String matricula) {
		Alumnos.matricula = matricula;
	}
	
	
	}

