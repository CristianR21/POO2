package calificaciones.materia.pojo;
import java.util.Enumeration;
/* Autor: Cristian Adair Ramirez Rodriguez
 * Materia:Paradigmas I
 * Fecha de creacion: 8 de mayo
 * Fecha de modificiación 4 de mayo
 * Grupo:406
*/
import java.util.Hashtable;
public class Calificacion {	
	
	public static Hashtable<String, Double> Mashtable() {
		Hashtable<String, Double> calificacion=new Hashtable<String, Double>();
		calificacion.put("11",9.0);
		//calificacion.put("12", "8");
		//calificacion.put("13", "9");
		//calificacion.put("14", "6");
		
		
		//calificacion.put("21", "8");
		//calificacion.put("22", "8");
		//calificacion.put("23", "8");
		//calificacion.put("24", "8");
		
		//calificacion.put("31", "8");
		//calificacion.put("32", "8");
		//calificacion.put("33", "6");
		//calificacion.put("34", "8");
		
		//calificacion.put("41", "8");
		//calificacion.put("42", "8");
		//calificacion.put("43", "8");
		//calificacion.put("44", "8");
		
		//calificacion.put("51", "8");
		//calificacion.put("52", "8");
		//calificacion.put("53", "8");
		//calificacion.put("54", "8");

		Enumeration enumeration = calificacion.elements();
		while (enumeration.hasMoreElements()) {
		  System.out.println(""+"hashtable valores: " + enumeration.nextElement());
		}
		return calificacion;
	}
	
	
	
}