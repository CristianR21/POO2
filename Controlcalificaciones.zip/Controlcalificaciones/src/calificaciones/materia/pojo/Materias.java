package calificaciones.materia.pojo;
/* Autor: Cristian Adair Ramirez Rodriguez 
 * Materia:Paradigmas I
 * Fecha de creacion: 22 de abril
 * Fecha de modificiacion 29 de abril
 * Grupo:406
*/
//import java.util.Scanner;

public class Materias {
	private static String nombre1; //nombre; Logica, mate, algoritmos, admon, filosofia
	private static String nombre2; 
	private static String nombre3; 
	private static String nombre4; 
	private static String nombre5; 
	
	public static String getNombre1() {
		return nombre1;
	}

	public static void setNombre1(String nombre) {
		Materias.nombre1 = nombre;
	}

	public static String getNombre2() {
		return nombre2;
	}

	public static void setNombre2(String nombre2) {
		Materias.nombre2 = nombre2;
	}

	public static String getNombre3() {
		return nombre3;
	}

	public static void setNombre3(String nombre3) {
		Materias.nombre3 = nombre3;
	}

	public static String getNombre4() {
		return nombre4;
	}

	public static void setNombre4(String nombre4) {
		Materias.nombre4 = nombre4;
	}

	public static String getNombre5() {
		return nombre5;
	}

	public static void setNombre5(String nombre5) {
		Materias.nombre5 = nombre5;
	}



}