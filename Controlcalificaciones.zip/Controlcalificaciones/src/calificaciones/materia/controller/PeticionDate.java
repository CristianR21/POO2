package calificaciones.materia.controller;

import javax.swing.JOptionPane;

import calificaciones.materia.pojo.Alumnos;

public class PeticionDate {

	public static void Alumno(Alumnos a , Alumnos b , Alumnos c, Alumnos d) {
	String nombre = JOptionPane.showInputDialog("Nombre del alumno:  ");
	Alumnos.setNombre(nombre);
	String grupo=JOptionPane.showInputDialog("Grupo del alumno:  ");
	Alumnos.setGrupo(grupo);
	String semestre = JOptionPane.showInputDialog( "Semestre que cursa el alumno");
	Alumnos.setSemestre(semestre);
	String matricula=JOptionPane.showInputDialog("deme su matricula");
	Alumnos.setMatricula(matricula);

}		
}