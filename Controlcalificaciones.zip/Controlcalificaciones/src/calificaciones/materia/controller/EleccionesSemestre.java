package calificaciones.materia.controller;

import java.util.Scanner;
import calificaciones.materia.pojo.*;

/* Autor: Cristian Adair Ramirez Rodriguez
 * Materia:Paradigmas I
 * Fecha de creacion: 22 de abril
 * Fecha de modificiacion 25 de abril
 * Grupo:406
*/

public class EleccionesSemestre {
	static Scanner s = new Scanner(System.in);
	public void EleccionSemestre(Materias a, Materias b, Materias c, Materias d, Materias e) {
		int opc = 0;
		System.out.println("Dime en que semestre vas :");
		System.out.println(
				"1semestre 1(1) : \n2semestre  2(2) :\n3semestre  3(3) : \n4semestre  4(4) :\n5semestre  5(5) : \n6semestre  6(6) : \n7semestre  7(7) : \n8semestre  8(8) :  \n9semestre  9(9) :"
						+ "\n10semestre 10(10) :" + " \n5-Salir");
		opc = s.nextInt();
		switch (opc) {
		case 1:
			Semestre1();
			Materias.setNombre1("Matematicas 1");
			Materias.setNombre2("logica matematica");
			Materias.setNombre3("Administracion");
			Materias.setNombre4("Filosofia");
			Materias.setNombre5("Algoritmos");
			break;
		case 2:
			Semestre2();
			Materias.setNombre1("Matematicas 2");
			Materias.setNombre2("â€ƒElectrÃ³nica I ");
			Materias.setNombre3("â€ƒTeorÃ­a General de Sistemas ");
			Materias.setNombre4("â€ƒMatemÃ¡ticas Discretas ");
			Materias.setNombre5("Programacion estrucuturada");
			break;
		case 3:
			Semestre3();
			Materias.setNombre1("â€ƒEstructuras de Datos ");
			Materias.setNombre2("â€ƒâ€ƒElectrÃ³nica II  ");
			Materias.setNombre3("â€ƒDerecho y LegislaciÃ³n en InformÃ¡tica  ");
			Materias.setNombre4("â€ƒContabilidad ");
			Materias.setNombre5("â€ƒÃ�lgebra Lineal");
			break;
		case 4:
			Semestre4();
			Materias.setNombre1("â€ƒParadigmas de ProgramaciÃ³n I ");
			Materias.setNombre2("â€ƒDiseÃ±o Web ");
			Materias.setNombre3("â€ƒBases de Datos I ");
			Materias.setNombre4("â€ƒâ€ƒMÃ©todos NumÃ©ricos ");
			Materias.setNombre5("â€ƒProgramaciÃ³n de Sistemas ");
			break;
		case 5:
			Semestre5();
			Materias.setNombre1("â€ƒParadigmas de ProgramaciÃ³n II ");
			Materias.setNombre2("â€ƒIngenierÃ­a de Software I");
			Materias.setNombre3("â€ƒBases de Datos II ");
			Materias.setNombre4("â€ƒArquitectura de Computadoras ");
			Materias.setNombre5("â€ƒRedes I");
			break;
		case 6:
			Semestre6();
			Materias.setNombre1("â€ƒTecnologÃ­as Web I ");
			Materias.setNombre2("â€ƒâ€ƒIngenierÃ­a de Software II ");
			Materias.setNombre3("â€ƒTeorÃ­a General de Sistemas ");
			Materias.setNombre4("â€ƒSistemas Operativos I ");
			Materias.setNombre5("â€ƒRedes II");
			break;
		case 7:
			Semestre7();
			Materias.setNombre1("â€ƒTecnologÃ­as Web II ");
			Materias.setNombre2("â€ƒProyectos de TecnologÃ­as de InformaciÃ³n ");
			Materias.setNombre3("â€ƒBases de Datos Distribuidas ");
			Materias.setNombre4("â€ƒSistemas Operativos II ");
			Materias.setNombre5("â€ƒEstadÃ­stica");
			break;
		case 8:
			Semestre8();
			Materias.setNombre1("â€ƒSistemas Distribuidos ");
			Materias.setNombre2("â€ƒCalidad de Software ");
			Materias.setNombre3("â€ƒInteracciÃ³n Humano â€“ Computadora ");
			Materias.setNombre4("â€ƒOrganizaciÃ³n de Centros de InformÃ¡tica ");
			Materias.setNombre5("â€ƒInvestigaciÃ³n de Operaciones");
			break;
		case 9:
			Semestre9();
			Materias.setNombre1("â€ƒMetodologÃ­a de la InvestigaciÃ³n ");
			Materias.setNombre2("â€ƒSeguridad de Centros de InformÃ¡tica ");
			Materias.setNombre3("â€ƒTeorÃ­a de Algoritmos ");
			Materias.setNombre4("â€ƒOptativa 1 ");
			Materias.setNombre5("â€ƒOptativa 2");
			break;
		case 10:
			Semestre10();
			Materias.setNombre1("â€ƒSeminario de Tesis ");
			Materias.setNombre2("â€ƒAuditorÃ­a de Sistemas ");
			Materias.setNombre3("â€ƒFunciÃ³n InformÃ¡tica ");
			Materias.setNombre4("â€ƒOptativa 3 ");
			Materias.setNombre5("â€ƒOptativa 4");
			break;
		}
	}

	private static void Semestre10() {
	}

	private static void Semestre9() {
		// TODO Auto-generated method stub

	}

	private static void Semestre8() {
		// TODO Auto-generated method stub

	}

	private static void Semestre7() {
		// TODO Auto-generated method stub

	}

	private static void Semestre6() {
		// TODO Auto-generated method stub

	}

	private static void Semestre5() {
		// TODO Auto-generated method stub

	}

	private static void Semestre4() {
		// TODO Auto-generated method stub

	}

	public static void Semestre3() {
		// TODO Auto-generated method stub

	}

	public static void Semestre2() {
		// TODO Auto-generated method stub

	}

	public static void Semestre1() {

	}
	
	

}
